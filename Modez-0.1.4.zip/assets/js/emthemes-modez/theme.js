import $ from 'jquery';
import 'slick-carousel/slick/slick';

export default function () {
    const $carousel = $('[data-emthemesmodez-instafeed-carousel]');

    if ($carousel.length) {
        $carousel.on('instafeedAfter', (e) => {
            const $el = $(e.target);
            $el.slick($el.data('emthemesmodezInstafeedCarousel'));
        });
    }
}
