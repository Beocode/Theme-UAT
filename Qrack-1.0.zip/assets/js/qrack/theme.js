import $ from 'jquery';
import 'foundation-sites/js/foundation/foundation.tab';

// Do the magic!
$(document).ready(function () {
    /* Run function after window resize */
    const afterResize = (function () {
        const t = {};
        return function (callback, ms, uniqueId) {
            let _uniqueId = uniqueId;
            if (_uniqueId !== null) {
                _uniqueId = "Don't call this twice without a uniqueId";
            }
            if (t[_uniqueId]) {
                clearTimeout(t[_uniqueId]);
            }
            t[_uniqueId] = setTimeout(callback, ms);
        };
    }());

    // Reviews tab scroll
    $('a[href*="#product-reviews"]').click(function () {
        $('a[href="#tab-reviews"]').trigger('click');
        // $('#tabs').foundation('selectTab', $('#tab-reviews'));
        return false;
    });
    // &
    // Smooth scrolling
    $('a[href*="#"]:not([href="#"]):not(li.tab a[href*="#"])').click(function () {
        if (location.pathname.replace(/^\//, '') === this.pathname.replace(/^\//, '') && location.hostname === this.hostname) {
            let target = $(this.hash);
            target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
            if (target.length) {
                $('html, body').animate({
                    scrollTop: target.offset().top - 115,
                }, 800);

                return false;
            }
        }
    });

    // Set up beocode menu functions
    const beocode = {};
    window.beocode = window.beocode || {};

    function beocodeCacheSelectors() {
        beocode.cache = {
            // Breakpoints (from _styles.scss)
            bpLarge: 800, // 769

            // Navigation
            $navigation: $('#mainList.withMoreMenu'),
        };
    }

    // preventDefault for no-link menu items
    $('.navPages a[href="#"]').click(function () {
        return false;
    });

    // nav_more_link
    function beocodeAlignMenu() {
        const $nav = beocode.cache.$navigation;
        let w = 0;
        let i = 0;

        const wrapperWidth = $nav.outerWidth() - 201;

        let menuhtml = '';

        if (window.innerWidth < beocode.cache.bpLarge) {
            return;
        }

        $.each($nav.children(), function () {
            const $el = $(this);

            // Ignore hidden customer links (for mobile)
            if (!$el.hasClass('large-hide')) {
                w += $el.outerWidth(true);
            }

            if (wrapperWidth < w) {
                menuhtml += $('<div>').append($el.clone()).html();
                $el.remove();

                // Ignore hidden customer links (for mobile)
                if (!$el.hasClass('large-hide')) {
                    i++;
                }
            }
        });

        if (wrapperWidth < w) {
            $nav.append(
                '<li id="moreMenu" class="navPages-item"><a class="navPages-action" href="#">More <i class="fa fa-angle-down" aria-hidden="true"></i></a><ul id="moreMenu--list" class="navPages-item">' + menuhtml + '</ul></li>'
            );

            if (i <= 1) {
                // Bail, and replace original nav items
                beocode.cache.$navigation.append($('#moreMenu--list').html());
                $('#moreMenu').remove();
            }
        }
    }

    // mobile toggle bg
    $('.header').on('click', '.mobileMenu-toggle', function () {
        if ($(this).hasClass('is-open')) {
            $(this).parent().addClass('is-open');
        } else {
            $(this).parent().removeClass('is-open');
        }
    });

    function beocodeResponsiveNav() {
        $(window).resize(function () {
            afterResize(function () {
                // Replace original nav items and remove more link
                beocode.cache.$navigation.append($('#moreMenu--list').html());
                $('#moreMenu').remove();
                beocodeAlignMenu();
            }, 200, 'uniqueId');
        });
        beocodeAlignMenu();
    }
    // end nav_more_link

    function beocodeInit() {
        beocodeCacheSelectors();

        // Wait until fonts load to attempt creating 'more' link in nav
        $(window).load(function () {
            beocodeResponsiveNav();
        });
    }

    // Sticky top navigation
    const stickyNavTop = $('#menu').offset().top;

    const stickyNav = function () {
        const scrollTop = $(window).scrollTop();
        const wW = $('body').width();

        if (wW > 800) {
            if (scrollTop > stickyNavTop) {
                $('#menu').addClass('sticky');
                $('body').addClass('sticky-move');
            } else {
                $('#menu').removeClass('sticky');
                $('body').removeClass('sticky-move');
            }
        }
    };

    stickyNav();

    $(window).scroll(function () {
        stickyNav();
    });

    beocodeInit();

    // Disable moreMenu link clicking
    $('#mainList').on('click', '#moreMenu > a', function (e) {
        e.preventDefault();
    });

    // Return click function to menu parent links
    /* maybe not needed due to 'all' link in submenu, uncomment following function to have this option if needed */
    /* $('.has-subMenu').click(function () {
        window.location.href = $(this).attr('href');
    });*/

    // Submenu functions for mobile
    // $('.has-subMenu').click(function () {
    //    $(this).find('.navPage-subMenu .navPage-subMenu-list').toggleSlide();
    // });

    // Add carousel to product images if number of images is bigger than 4
    if ($('.productView-thumbnails li').length > 4) {
        $('.productView-thumbnails').slick({
            infinite: true,
            slidesToShow: 4,
            slidesToScroll: 4,
        });
    }

    // Add arrows bg to carousel only if number of slides is bigger than 5
    $('.productCarousel').each(function () {
        if ($(this).find('.productCarousel-slide').length > 5) {
            $(this).addClass('withArrows');
        }
    });

    // Vertical center blog images on listing page if full size
    $('.blog-listing .blog-thumbnail img').each(function () {
        const elh = $(this).height();
        const elw = $(this).width();
        const pelw = $(this).parent().width();
        if (elw >= pelw && elh >= 300) {
            $(this).addClass('valinged');
        }
    });

    // Category product count
    const nop = $('#product-listing-container ul li.product').length;
    $('.number-of-pages .cn').html(nop);
    $('.number-of-pages').css('display', 'inline-block');
    const nopClone = $('.number-of-pages').clone();
    nopClone.appendTo('.bottom-number-of-pages');

    // Product color options select
    $('[data-product-attribute="set-rectangle"] .form-option').click(function () {
        $(this).parent().find('.form-option').removeClass('selected');
        $(this).addClass('selected');
    });

    // Remove item from wishlist
    $('.remove-wishlist-item .remover').click(function () {
        $(this).parent().find('input').trigger('click');
    });

    // Wishlist number in header
    // $('#load-wishlist').load('/wishlist.php #wishlist-totals');
});
